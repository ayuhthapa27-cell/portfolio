export const profile = {
  name: "Ayush Thapa",
  initials: "AT",
  title: "Student & Aspiring Web Developer",
  /** Put your background-less PNG in /public (e.g. /public/me.png) and set this to "/me.png" */
  image: "",
  tagline:
    "Welcome to my personal portfolio website! Explore my projects and learn more about my journey below.",
  email: "ayushthapa27@gmail.com",
  phone: "+977 9742347685",
  phoneHref: "tel:+9779742347685",
  location: "Nepal",
  roles: [
    "Student",
    "Aspiring Web Developer",
    "Problem Solver",
    "Future Full-Stack Dev",
  ],
  socials: {
    facebook: "https://facebook.com",
    instagram: "https://instagram.com",
    github: "https://github.com",
  },
};

export const about = {
  paragraphs: [
    "Hello! I am a passionate student currently learning web development and programming. I enjoy solving problems, building creative web pages, and exploring new technologies.",
    "My goal is to become a full-stack software developer. In my free time, I like reading tech blogs, practicing code, and working on beginner-friendly web design projects to improve my skills step by step.",
  ],
  focus: [
    "Building clean, responsive layouts",
    "Strengthening JavaScript fundamentals",
    "Daily Git & GitHub workflow",
    "Learning React and modern tooling",
  ],
  stats: [
    { value: "3+", label: "Projects Built" },
    { value: "6", label: "Core Skills" },
    { value: "∞", label: "Curiosity" },
  ],
};

export type SkillIcon =
  | "html"
  | "css"
  | "js"
  | "git"
  | "brain"
  | "responsive";

export interface Skill {
  name: string;
  short: string;
  level: number;
  icon: SkillIcon;
  color: string;
  description: string;
}

export const skills: Skill[] = [
  {
    name: "HTML5",
    short: "HTML",
    level: 85,
    icon: "html",
    color: "#fb923c",
    description:
      "Structuring semantic, accessible and responsive web pages from the ground up.",
  },
  {
    name: "CSS3",
    short: "CSS",
    level: 80,
    icon: "css",
    color: "#38bdf8",
    description:
      "Styling with Flexbox, Grid, transitions and animations for pixel-perfect layouts.",
  },
  {
    name: "JavaScript",
    short: "JS",
    level: 60,
    icon: "js",
    color: "#facc15",
    description:
      "Adding interactivity and dynamic actions to websites with DOM & events.",
  },
  {
    name: "Git & GitHub",
    short: "Git",
    level: 65,
    icon: "git",
    color: "#f472b6",
    description:
      "Version control, branching and sharing code projects online.",
  },
  {
    name: "Problem Solving",
    short: "Logic",
    level: 70,
    icon: "brain",
    color: "#a78bfa",
    description:
      "Logic building and basic algorithmic thinking to break problems down.",
  },
  {
    name: "Responsive Design",
    short: "UI",
    level: 75,
    icon: "responsive",
    color: "#34d399",
    description:
      "Mobile-first interfaces that look great on every screen size.",
  },
];

export const learning = [
  "React",
  "TypeScript",
  "Tailwind CSS",
  "Node.js",
  "Three.js",
  "REST APIs",
  "Figma",
  "Vite",
  "MongoDB",
  "Express",
];

export interface Project {
  id: string;
  number: string;
  title: string;
  description: string;
  tags: string[];
  mock: "portfolio" | "calculator" | "quiz";
  accent: string;
  demo: string;
  source: string;
}

export const projects: Project[] = [
  {
    id: "portfolio",
    number: "01",
    title: "Personal Portfolio Website",
    description:
      "A single-page portfolio created using HTML and CSS featuring smooth scrolling, responsive alignment and social media integration — now rebuilt with React & 3D.",
    tags: ["HTML", "CSS", "Responsive"],
    mock: "portfolio",
    accent: "from-emerald-500/30 via-cyan-500/10 to-transparent",
    demo: "#home",
    source: "https://github.com",
  },
  {
    id: "calculator",
    number: "02",
    title: "Digital Calculator",
    description:
      "An online calculator built to practice JavaScript logic, button events and operations like addition, subtraction, multiplication and division.",
    tags: ["JavaScript", "DOM", "Logic"],
    mock: "calculator",
    accent: "from-cyan-500/30 via-violet-500/10 to-transparent",
    demo: "#",
    source: "https://github.com",
  },
  {
    id: "quiz",
    number: "03",
    title: "Interactive Quiz App",
    description:
      "A multiple-choice quiz page that tracks answers, calculates the score and gives users immediate feedback upon completion.",
    tags: ["JavaScript", "UI/UX", "State"],
    mock: "quiz",
    accent: "from-violet-500/30 via-pink-500/10 to-transparent",
    demo: "#",
    source: "https://github.com",
  },
];

export interface EducationItem {
  title: string;
  subtitle: string;
  status: string;
  statusTone: "live" | "done";
  period: string;
  description: string;
  icon: "cap" | "book" | "code";
}

export const education: EducationItem[] = [
  {
    title: "Computer Science / School Studies",
    subtitle: "Academic Studies",
    status: "Currently Pursuing",
    statusTone: "live",
    period: "Present",
    description:
      "Focusing on computer fundamentals, basic programming languages and web technologies.",
    icon: "cap",
  },
  {
    title: "Web Development Training",
    subtitle: "Front-end Foundations",
    status: "Ongoing",
    statusTone: "live",
    period: "2025 — Present",
    description:
      "HTML5, CSS layout design (Flexbox & Grid), responsive patterns and basic site structuring.",
    icon: "book",
  },
  {
    title: "Self-Learning & Practice",
    subtitle: "Docs, tutorials & projects",
    status: "Always",
    statusTone: "done",
    period: "Every day",
    description:
      "Reading tech blogs, practising JavaScript and shipping small beginner-friendly projects to level up step by step.",
    icon: "code",
  },
];

export const navLinks = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "skills", label: "Skills" },
  { id: "projects", label: "Projects" },
  { id: "education", label: "Education" },
  { id: "contact", label: "Contact" },
];
