import { ArrowUp, Heart } from "lucide-react";
import { navLinks, profile } from "../data/portfolio";

interface FooterProps {
  onOpenCssModal?: () => void;
}

export default function Footer({ onOpenCssModal }: FooterProps) {
  const year = new Date().getFullYear();

  return (
    <footer className="relative mt-10 border-t border-white/10">
      <div className="absolute inset-x-0 top-0 h-px bg-linear-to-r from-transparent via-emerald-400/60 to-transparent" />

      <div className="container-x py-12">
        <div className="flex flex-col items-center justify-between gap-8 md:flex-row">
          <a href="#home" className="font-display flex items-center gap-2 text-xl font-bold text-white">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-linear-to-br from-emerald-400 to-cyan-400 text-sm font-black text-ink-950">
              {profile.initials}
            </span>
            {profile.name.split(" ")[0]}
            <span className="gradient-text">.</span>
          </a>

          <ul className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
            {navLinks.map((l) => (
              <li key={l.id}>
                <a
                  href={`#${l.id}`}
                  className="text-sm text-slate-400 transition-colors hover:text-emerald-300"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>

          <a
            href="#home"
            aria-label="Back to top"
            className="group grid h-11 w-11 place-items-center rounded-xl border border-white/10 bg-white/5 text-slate-300 transition-all hover:-translate-y-1 hover:border-emerald-400/50 hover:text-emerald-300"
          >
            <ArrowUp size={18} className="transition-transform group-hover:-translate-y-0.5" />
          </a>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-white/5 pt-6 text-sm text-slate-500 md:flex-row">
          <div className="flex flex-wrap items-center gap-3">
            <p>
              © {year} {profile.name}. All Rights Reserved.
            </p>
            {onOpenCssModal && (
              <button
                type="button"
                onClick={onOpenCssModal}
                className="inline-flex items-center gap-1 rounded-md border border-white/10 bg-white/5 px-2.5 py-1 text-xs font-medium text-emerald-300 transition-colors hover:border-emerald-400/40 hover:bg-white/10"
              >
                <span>style.css & HTML</span>
              </button>
            )}
          </div>
          <p className="inline-flex items-center gap-1.5">
            Built with <Heart size={13} className="fill-rose-400 text-rose-400" /> using React,
            Three.js & Tailwind CSS
          </p>
        </div>
      </div>
    </footer>
  );
}
