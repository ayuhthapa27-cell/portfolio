import type { ReactNode } from "react";
import { cn } from "../../utils/cn";
import { useReveal } from "../../hooks/useReveal";

type Direction = "up" | "down" | "left" | "right" | "zoom";

interface RevealProps {
  children: ReactNode;
  className?: string;
  delay?: number;
  direction?: Direction;
  duration?: number;
}

const hidden: Record<Direction, string> = {
  up: "opacity-0 translate-y-10",
  down: "opacity-0 -translate-y-10",
  left: "opacity-0 -translate-x-10",
  right: "opacity-0 translate-x-10",
  zoom: "opacity-0 scale-90",
};

export default function Reveal({
  children,
  className,
  delay = 0,
  direction = "up",
  duration = 700,
}: RevealProps) {
  const { ref, visible } = useReveal<HTMLDivElement>();

  return (
    <div
      ref={ref}
      className={cn(
        "transition-all ease-out",
        visible
          ? "translate-x-0 translate-y-0 scale-100 opacity-100"
          : hidden[direction],
        className
      )}
      style={{ transitionDelay: `${delay}ms`, transitionDuration: `${duration}ms` }}
    >
      {children}
    </div>
  );
}
