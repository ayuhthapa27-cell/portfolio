import type { ComponentType, CSSProperties } from "react";
import {
  Braces,
  BrainCircuit,
  CodeXml,
  GitBranch,
  MonitorSmartphone,
  Palette,
  Rocket,
} from "lucide-react";
import SectionHeading from "./ui/SectionHeading";
import Reveal from "./ui/Reveal";
import { learning, skills, type SkillIcon } from "../data/portfolio";

const iconMap: Record<SkillIcon, ComponentType<{ size?: number; className?: string; style?: CSSProperties }>> = {
  html: CodeXml,
  css: Palette,
  js: Braces,
  git: GitBranch,
  brain: BrainCircuit,
  responsive: MonitorSmartphone,
};

const faces = ["front", "back", "right", "left", "top", "bottom"] as const;

function SkillCube() {
  return (
    <div className="relative flex flex-col items-center">
      {/* Glow */}
      <div className="absolute top-1/2 left-1/2 -z-10 h-64 w-64 -translate-x-1/2 -translate-y-1/2 rounded-full bg-emerald-500/20 blur-3xl" />

      <div className="cube-scene">
        <div className="cube">
          {skills.map((skill, i) => {
            const Icon = iconMap[skill.icon];
            return (
              <div key={skill.name} className={`cube-face ${faces[i]}`}>
                <span
                  className="grid h-14 w-14 place-items-center rounded-2xl border border-white/10"
                  style={{
                    background: `${skill.color}22`,
                    color: skill.color,
                    boxShadow: `0 0 30px ${skill.color}33`,
                  }}
                >
                  <Icon size={28} />
                </span>
                <span className="font-display text-lg font-bold text-white">
                  {skill.short}
                </span>
                <span className="text-[10px] tracking-[0.25em] text-slate-400 uppercase">
                  {skill.name}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* floor shadow */}
      <div className="mt-14 h-6 w-48 rounded-[100%] bg-emerald-400/25 blur-xl sm:w-60" />
      <p className="mt-4 text-xs tracking-widest text-slate-500 uppercase">
        Hover to pause
      </p>
    </div>
  );
}

function SkillCard({ index }: { index: number }) {
  const skill = skills[index];
  const Icon = iconMap[skill.icon];

  return (
    <Reveal delay={index * 80} className="h-full">
      <div className="flip-card h-44 sm:h-48" tabIndex={0}>
        <div className="flip-inner">
          {/* front */}
          <div className="flip-face card-border flex flex-col justify-between rounded-2xl border border-white/10 bg-ink-900/70 p-5 backdrop-blur-sm">
            <div className="flex items-start justify-between">
              <span
                className="grid h-11 w-11 place-items-center rounded-xl"
                style={{ background: `${skill.color}1f`, color: skill.color }}
              >
                <Icon size={22} />
              </span>
              <span className="font-display text-sm font-bold text-slate-500">
                {skill.level}%
              </span>
            </div>
            <div>
              <h3 className="font-display text-lg font-semibold text-white">
                {skill.name}
              </h3>
              <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${skill.level}%`,
                    background: `linear-gradient(90deg, ${skill.color}, #67e8f9)`,
                    boxShadow: `0 0 12px ${skill.color}80`,
                  }}
                />
              </div>
            </div>
          </div>

          {/* back */}
          <div
            className="flip-face flip-back flex flex-col justify-between rounded-2xl border p-5"
            style={{
              borderColor: `${skill.color}55`,
              background: `linear-gradient(145deg, ${skill.color}26, rgba(10,14,24,0.95) 60%)`,
            }}
          >
            <p className="text-xs font-semibold tracking-widest uppercase" style={{ color: skill.color }}>
              {skill.name}
            </p>
            <p className="text-sm leading-relaxed text-slate-200">
              {skill.description}
            </p>
            <div className="flex items-center gap-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <span
                  key={i}
                  className="h-1.5 flex-1 rounded-full"
                  style={{
                    background:
                      i < Math.round(skill.level / 20)
                        ? skill.color
                        : "rgba(255,255,255,0.12)",
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </Reveal>
  );
}

export default function Skills() {
  return (
    <section id="skills" className="section">
      <div className="container-x">
        <SectionHeading
          eyebrow="Skills"
          align="center"
          title={
            <>
              My <span className="gradient-text">toolbox</span>
            </>
          }
          description="Here are some of the technologies and tools I am currently working with. Flip the cards to learn more."
        />

        <div className="mt-16 grid items-center gap-14 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
          <Reveal direction="zoom" className="order-1">
            <SkillCube />
          </Reveal>

          <div className="order-2 grid gap-4 sm:grid-cols-2">
            {skills.map((_, i) => (
              <SkillCard key={skills[i].name} index={i} />
            ))}
          </div>
        </div>

        {/* Currently learning marquee */}
        <Reveal delay={150} className="mt-20">
          <div className="mb-5 flex items-center justify-center gap-2 text-sm font-semibold text-slate-300">
            <Rocket size={16} className="text-cyan-300" />
            Currently exploring
          </div>
          <div className="mask-fade-x relative overflow-hidden py-2">
            <div className="animate-marquee flex w-max gap-3">
              {[...learning, ...learning].map((item, i) => (
                <span
                  key={`${item}-${i}`}
                  className="chip border-white/10 bg-white/5 px-4 py-2 text-sm text-slate-200 transition-colors hover:border-emerald-400/40 hover:text-emerald-300"
                >
                  <span className="h-1.5 w-1.5 rounded-full bg-linear-to-r from-emerald-400 to-cyan-400" />
                  {item}
                </span>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
