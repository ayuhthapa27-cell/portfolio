import { Check, MapPin, GraduationCap, ArrowRight, Braces, Palette, CodeXml } from "lucide-react";
import SectionHeading from "./ui/SectionHeading";
import Reveal from "./ui/Reveal";
import TiltCard from "./ui/TiltCard";
import { about, profile } from "../data/portfolio";

export default function About() {
  return (
    <section id="about" className="section">
      <div className="container-x grid items-center gap-14 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:gap-20">
        {/* ---------- 3D Profile card ---------- */}
        <Reveal direction="left" className="order-2 lg:order-1">
          <div className="relative mx-auto max-w-sm">
            <div className="absolute -inset-6 -z-10 rounded-[2.5rem] bg-linear-to-br from-emerald-500/20 via-cyan-500/10 to-violet-500/20 blur-2xl" />

            <TiltCard max={12} scale={1.03} className="rounded-3xl">
              {/* surface */}
              <div className="card-border glass absolute inset-0 rounded-3xl" />
              <div className="dot-pattern absolute inset-0 rounded-3xl opacity-40 [mask-image:linear-gradient(to_bottom,black,transparent)]" />

              {/* content */}
              <div className="relative p-7 sm:p-8">
                <div className="depth-1 flex items-center justify-between">
                  <span className="chip border-emerald-400/30 bg-emerald-400/10 text-emerald-300">
                    <MapPin size={12} /> {profile.location}
                  </span>
                  <span className="text-xs font-semibold tracking-widest text-slate-500 uppercase">
                    Student
                  </span>
                </div>

                <div className="depth-2 relative mx-auto mt-8 h-44 w-44">
                  <div className="animate-spin-slow absolute inset-0 rounded-full bg-[conic-gradient(from_0deg,#34d399,#22d3ee,#a78bfa,#34d399)] opacity-90" />
                  <div className="animate-spin-reverse absolute -inset-3 rounded-full border border-dashed border-emerald-400/30" />
                  <div className="absolute inset-[5px] overflow-hidden rounded-full bg-ink-900">
                    {profile.image ? (
                      <img
                        src={profile.image}
                        alt={profile.name}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="grid h-full w-full place-items-center bg-[radial-gradient(circle_at_30%_20%,rgba(52,211,153,0.35),transparent_55%),radial-gradient(circle_at_70%_80%,rgba(34,211,238,0.3),transparent_55%)]">
                        <span className="font-display text-5xl font-bold text-white drop-shadow-[0_0_20px_rgba(52,211,153,0.5)]">
                          {profile.initials}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="depth-1 mt-8 text-center">
                  <h3 className="font-display text-2xl font-bold text-white">
                    {profile.name}
                  </h3>
                  <p className="mt-1 text-sm font-medium text-emerald-300">
                    {profile.title}
                  </p>
                </div>

                <div className="depth-1 mt-7 grid grid-cols-3 divide-x divide-white/10 rounded-2xl border border-white/10 bg-white/5">
                  {about.stats.map((s) => (
                    <div key={s.label} className="px-2 py-3 text-center">
                      <p className="font-display text-xl font-bold text-white">
                        {s.value}
                      </p>
                      <p className="text-[11px] text-slate-400">{s.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* floating badges */}
              <div className="depth-3 animate-float absolute -top-4 -right-3 flex items-center gap-2 rounded-xl border border-orange-400/30 bg-ink-900/90 px-3 py-2 text-xs font-semibold text-orange-300 shadow-lg shadow-black/40 backdrop-blur">
                <CodeXml size={14} /> HTML5
              </div>
              <div className="depth-3 animate-float-slow absolute top-1/2 -left-5 flex items-center gap-2 rounded-xl border border-sky-400/30 bg-ink-900/90 px-3 py-2 text-xs font-semibold text-sky-300 shadow-lg shadow-black/40 backdrop-blur [animation-delay:-2s]">
                <Palette size={14} /> CSS3
              </div>
              <div className="depth-3 animate-float absolute -right-4 bottom-20 flex items-center gap-2 rounded-xl border border-yellow-400/30 bg-ink-900/90 px-3 py-2 text-xs font-semibold text-yellow-300 shadow-lg shadow-black/40 backdrop-blur [animation-delay:-4s]">
                <Braces size={14} /> JavaScript
              </div>
            </TiltCard>
          </div>
        </Reveal>

        {/* ---------- Copy ---------- */}
        <div className="order-1 lg:order-2">
          <SectionHeading
            eyebrow="About me"
            title={
              <>
                Turning curiosity into{" "}
                <span className="gradient-text">code</span>
              </>
            }
          />

          <div className="mt-6 space-y-4">
            {about.paragraphs.map((p, i) => (
              <Reveal key={i} delay={100 + i * 100}>
                <p className="text-base leading-relaxed text-slate-400 md:text-lg">
                  {p}
                </p>
              </Reveal>
            ))}
          </div>

          <Reveal delay={300}>
            <div className="mt-8 rounded-2xl border border-white/10 bg-white/5 p-5">
              <p className="flex items-center gap-2 text-sm font-semibold text-white">
                <GraduationCap size={16} className="text-emerald-400" />
                What I'm focused on right now
              </p>
              <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                {about.focus.map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-sm text-slate-300">
                    <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-emerald-400/15 text-emerald-300">
                      <Check size={12} strokeWidth={3} />
                    </span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>

          <Reveal delay={400}>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#contact" className="btn-primary group">
                Let's work together
                <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
              </a>
              <a href="#skills" className="btn-ghost">
                Explore my skills
              </a>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
