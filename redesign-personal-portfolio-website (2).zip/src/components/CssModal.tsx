import { useState } from "react";
import { X, Copy, Check, Download, FileCode, Sparkles, Box, ExternalLink } from "lucide-react";

interface CssModalProps {
  open: boolean;
  onClose: () => void;
}

export default function CssModal({ open, onClose }: CssModalProps) {
  const [activeTab, setActiveTab] = useState<"css" | "html" | "guide">("css");
  const [copied, setCopied] = useState(false);

  if (!open) return null;

  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  const handleDownload = (filename: string, path: string) => {
    const a = document.createElement("a");
    a.href = path;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="css-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div className="card-border relative z-10 flex h-[90vh] w-full max-w-4xl flex-col overflow-hidden rounded-3xl bg-ink-900 border border-white/10 shadow-2xl shadow-black/80">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 bg-white/5 px-6 py-4">
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-linear-to-br from-emerald-400 to-cyan-400 text-ink-950 font-bold shadow-md shadow-emerald-500/20">
              <FileCode size={20} />
            </span>
            <div>
              <h2 id="css-modal-title" className="font-display text-lg font-bold text-white">
                Modern 3D <span className="gradient-text">style.css</span> & HTML
              </h2>
              <p className="text-xs text-slate-400">
                Pure CSS with 3D cube, tilt perspective & cyber glassmorphism
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href="/index-vanilla.html"
              target="_blank"
              rel="noreferrer"
              className="hidden sm:inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-slate-300 transition-colors hover:border-emerald-400/40 hover:text-emerald-300"
            >
              <ExternalLink size={13} />
              Open Vanilla HTML
            </a>
            <button
              onClick={onClose}
              className="grid h-9 w-9 place-items-center rounded-xl border border-white/10 bg-white/5 text-slate-400 transition-colors hover:border-white/20 hover:text-white"
              aria-label="Close modal"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Tabs & Action Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 bg-white/[0.02] px-6 py-2.5">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setActiveTab("css")}
              className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
                activeTab === "css"
                  ? "bg-emerald-400/15 text-emerald-300 border border-emerald-400/30 shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              style.css (Modern 3D)
            </button>
            <button
              onClick={() => setActiveTab("html")}
              className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
                activeTab === "html"
                  ? "bg-cyan-400/15 text-cyan-300 border border-cyan-400/30 shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              index.html (Vanilla)
            </button>
            <button
              onClick={() => setActiveTab("guide")}
              className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-all ${
                activeTab === "guide"
                  ? "bg-violet-400/15 text-violet-300 border border-violet-400/30 shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              3D Effects Guide
            </button>
          </div>

          <div className="flex items-center gap-2">
            {activeTab === "css" && (
              <>
                <button
                  onClick={() => {
                    fetch("/style.css")
                      .then((r) => r.text())
                      .then(handleCopy);
                  }}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-slate-300 transition-colors hover:border-emerald-400/40 hover:text-emerald-300"
                >
                  {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                  {copied ? "Copied!" : "Copy CSS"}
                </button>
                <button
                  onClick={() => handleDownload("style.css", "/style.css")}
                  className="btn-primary !py-1.5 !px-3 !text-xs"
                >
                  <Download size={13} />
                  Download style.css
                </button>
              </>
            )}
            {activeTab === "html" && (
              <>
                <button
                  onClick={() => {
                    fetch("/index-vanilla.html")
                      .then((r) => r.text())
                      .then(handleCopy);
                  }}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-slate-300 transition-colors hover:border-emerald-400/40 hover:text-emerald-300"
                >
                  {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                  {copied ? "Copied!" : "Copy HTML"}
                </button>
                <button
                  onClick={() => handleDownload("index.html", "/index-vanilla.html")}
                  className="btn-primary !py-1.5 !px-3 !text-xs"
                >
                  <Download size={13} />
                  Download index.html
                </button>
              </>
            )}
          </div>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6 font-mono text-xs">
          {activeTab === "css" && (
            <div className="space-y-4">
              <div className="rounded-2xl border border-white/10 bg-black/40 p-5 leading-relaxed text-slate-300">
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-white/10 font-sans text-xs text-slate-400">
                  <span className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-emerald-400" />
                    style.css (Pure CSS • 3D Transforms • Drop-in replacement)
                  </span>
                  <span className="text-emerald-400 font-semibold">Ready to use</span>
                </div>
                <pre className="overflow-x-auto text-slate-200 whitespace-pre font-mono text-xs selection:bg-emerald-500/30">
{`/* AYUSH THAPA — MODERN 3D PORTFOLIO STYLESHEET (style.css) */
:root {
  --bg-deep: #05070d;
  --bg-card: rgba(14, 20, 34, 0.75);
  --bg-card-hover: rgba(22, 32, 54, 0.85);
  --border-glass: rgba(255, 255, 255, 0.1);
  --border-accent: rgba(52, 211, 153, 0.4);
  --emerald-400: #34d399;
  --cyan-400: #22d3ee;
  --cube-size: 150px;
}

/* Page Container Glassmorphism */
.page-container {
  max-width: 960px;
  margin: 0 auto;
  padding: 40px 32px;
  background: linear-gradient(145deg, rgba(16, 24, 40, 0.85), rgba(7, 11, 20, 0.92));
  border: 1px solid var(--border-glass);
  border-radius: 28px;
  backdrop-filter: blur(24px);
  box-shadow: 0 0 0 1px rgba(52, 211, 153, 0.15), 0 30px 60px -15px rgba(0, 0, 0, 0.7);
}

/* 3D Floating Avatar */
.profile-img, .hero-avatar {
  width: 200px;
  height: 200px;
  border-radius: 50%;
  animation: floatAvatar 6s ease-in-out infinite;
  box-shadow: 0 0 40px rgba(52, 211, 153, 0.4);
}
.profile-img:hover {
  transform: translateY(-8px) rotateX(10deg) rotateY(-10deg) scale(1.05);
}

/* 3D Spinning Cube */
.cube-wrapper {
  width: var(--cube-size);
  height: var(--cube-size);
  transform-style: preserve-3d;
  animation: rotateCube 18s linear infinite;
}
.cube-front  { transform: rotateY(0deg) translateZ(calc(var(--cube-size) / 2)); }
.cube-back   { transform: rotateY(180deg) translateZ(calc(var(--cube-size) / 2)); }
.cube-right  { transform: rotateY(90deg) translateZ(calc(var(--cube-size) / 2)); }
.cube-left   { transform: rotateY(-90deg) translateZ(calc(var(--cube-size) / 2)); }
.cube-top    { transform: rotateX(90deg) translateZ(calc(var(--cube-size) / 2)); }
.cube-bottom { transform: rotateX(-90deg) translateZ(calc(var(--cube-size) / 2)); }

@keyframes rotateCube {
  from { transform: rotateX(-20deg) rotateY(0deg); }
  to   { transform: rotateX(-20deg) rotateY(360deg); }
}

/* 3D Project & Education Tilt Cards */
.project-card, .edu-item {
  transform-style: preserve-3d;
  transition: all 0.45s cubic-bezier(0.16, 1, 0.3, 1);
}
.project-card:hover, .edu-item:hover {
  transform: translateY(-8px) rotateX(3deg) scale(1.015);
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7), 0 0 30px rgba(52, 211, 153, 0.2);
}`}
                </pre>
              </div>
            </div>
          )}

          {activeTab === "html" && (
            <div className="space-y-4">
              <div className="rounded-2xl border border-white/10 bg-black/40 p-5 leading-relaxed text-slate-300">
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-white/10 font-sans text-xs text-slate-400">
                  <span className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-cyan-400" />
                    index.html (Your original HTML modernized with 3D Cube & Cards)
                  </span>
                  <span className="text-cyan-400 font-semibold">Links style.css</span>
                </div>
                <pre className="overflow-x-auto text-slate-200 whitespace-pre font-mono text-xs selection:bg-cyan-500/30">
{`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayush Thapa — Portfolio</title>
    <!-- Link your style.css -->
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <div class="page-container">
        <nav class="navbar">
            <a href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#skills">Skills</a>
            <a href="#projects">Projects</a>
            <a href="#education">Education</a>
            <a href="#contact">Contact</a>
        </nav>
        <!-- Sections: #home, #about, #skills, #projects, #education, #contact -->
    </div>
</body>
</html>`}
                </pre>
              </div>
            </div>
          )}

          {activeTab === "guide" && (
            <div className="font-sans space-y-6 text-sm text-slate-300">
              <div className="rounded-2xl border border-emerald-400/20 bg-emerald-400/5 p-5">
                <h3 className="font-display flex items-center gap-2 text-base font-bold text-white">
                  <Sparkles size={18} className="text-emerald-400" />
                  What Changed From Your Previous CSS?
                </h3>
                <ul className="mt-3 space-y-2 text-xs leading-relaxed text-slate-300">
                  <li>
                    <strong className="text-emerald-300">1. Cyber Dark Palette:</strong> Replaced the flat blue (<code className="text-slate-400">rgb(23, 20, 226)</code>) and neon green (<code className="text-slate-400">#0ee09a</code>) with a deep cyber background (<code className="text-slate-400">#05070d</code>), glassmorphism cards with backdrop blur, and modern emerald-cyan gradient accents.
                  </li>
                  <li>
                    <strong className="text-emerald-300">2. Real 3D Spinning Cube:</strong> Added a pure CSS 3D cube with 6 faces created using <code className="text-slate-400">transform-style: preserve-3d</code> and <code className="text-slate-400">translateZ</code>.
                  </li>
                  <li>
                    <strong className="text-emerald-300">3. 3D Tilt Hover Effects:</strong> Cards now lift with <code className="text-slate-400">rotateX</code>, <code className="text-slate-400">translateY</code>, and dynamic glowing radial gradients.
                  </li>
                  <li>
                    <strong className="text-emerald-300">4. Floating Avatar:</strong> The profile image now floats smoothly and tilts into 3D on hover.
                  </li>
                  <li>
                    <strong className="text-emerald-300">5. Modern Sticky Pill Navbar:</strong> Frosted glass pill navbar that stays at the top with glowing hover states.
                  </li>
                </ul>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
                  <div className="flex items-center gap-2 font-display font-semibold text-white">
                    <Box size={16} className="text-cyan-400" />
                    How to use with your files
                  </div>
                  <ol className="mt-3 space-y-2 text-xs text-slate-400 list-decimal list-inside">
                    <li>Download both <code className="text-slate-200">style.css</code> and <code className="text-slate-200">index.html</code></li>
                    <li>Put them in the same folder on your computer</li>
                    <li>Double click <code className="text-slate-200">index.html</code> to open it in Chrome or Firefox!</li>
                  </ol>
                </div>

                <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
                  <div className="flex items-center gap-2 font-display font-semibold text-white">
                    <Sparkles size={16} className="text-violet-400" />
                    Hosted versions
                  </div>
                  <p className="mt-3 text-xs leading-relaxed text-slate-400">
                    Both files are also served directly on this website:
                  </p>
                  <div className="mt-2 space-y-1 text-xs">
                    <div><a href="/style.css" target="_blank" className="text-emerald-400 hover:underline">/style.css</a></div>
                    <div><a href="/index-vanilla.html" target="_blank" className="text-cyan-400 hover:underline">/index-vanilla.html</a></div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-white/10 bg-white/5 px-6 py-3 font-sans text-xs text-slate-400">
          <span>Both React 3D & Vanilla style.css are available!</span>
          <button
            onClick={onClose}
            className="rounded-xl border border-white/10 bg-white/5 px-4 py-2 font-semibold text-white transition-colors hover:bg-white/10"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
