import { Suspense, useEffect, useRef, type ReactNode } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Float, MeshDistortMaterial, Sparkles, Stars } from "@react-three/drei";
import { MathUtils, type Group, type Mesh } from "three";

type PointerRef = { current: { x: number; y: number } };

/* ---------- Parallax rig that follows the cursor across the whole page ---------- */
function Rig({ pointer, children }: { pointer: PointerRef; children: ReactNode }) {
  const group = useRef<Group>(null);
  const { viewport } = useThree();
  const scale = Math.min(1, viewport.width / 6.6);

  useFrame((_, delta) => {
    const g = group.current;
    if (!g) return;
    g.rotation.x = MathUtils.damp(g.rotation.x, -pointer.current.y * 0.3, 2.5, delta);
    g.rotation.y = MathUtils.damp(g.rotation.y, pointer.current.x * 0.45, 2.5, delta);
  });

  return (
    <group ref={group} scale={scale}>
      {children}
    </group>
  );
}

/* ---------- Central distorted blob ---------- */
function CoreBlob() {
  const mesh = useRef<Mesh>(null);

  useFrame((state) => {
    const m = mesh.current;
    if (!m) return;
    const t = state.clock.getElapsedTime();
    m.rotation.x = t * 0.12;
    m.rotation.y = t * 0.18;
  });

  return (
    <Float speed={1.5} rotationIntensity={0.5} floatIntensity={1.1}>
      <mesh ref={mesh}>
        <icosahedronGeometry args={[1.25, 40]} />
        <MeshDistortMaterial
          color="#10b981"
          emissive="#064e3b"
          emissiveIntensity={0.45}
          roughness={0.18}
          metalness={0.75}
          distort={0.42}
          speed={2.2}
        />
      </mesh>
    </Float>
  );
}

/* ---------- Slowly rotating wireframe shell ---------- */
function WireShell() {
  const mesh = useRef<Mesh>(null);
  useFrame((_, delta) => {
    const m = mesh.current;
    if (!m) return;
    m.rotation.y -= delta * 0.12;
    m.rotation.x += delta * 0.05;
  });
  return (
    <mesh ref={mesh} scale={1.95}>
      <icosahedronGeometry args={[1, 1]} />
      <meshBasicMaterial color="#34d399" wireframe transparent opacity={0.16} />
    </mesh>
  );
}

/* ---------- Tilted orbit ring with a glowing satellite ---------- */
interface OrbitProps {
  radius: number;
  tilt: [number, number, number];
  speed: number;
  color: string;
  size?: number;
}

function Orbit({ radius, tilt, speed, color, size = 0.09 }: OrbitProps) {
  const spinner = useRef<Group>(null);
  useFrame((_, delta) => {
    if (spinner.current) spinner.current.rotation.z += delta * speed;
  });

  return (
    <group rotation={tilt}>
      <mesh>
        <torusGeometry args={[radius, 0.016, 12, 180]} />
        <meshBasicMaterial color={color} transparent opacity={0.38} />
      </mesh>
      <group ref={spinner}>
        <mesh position={[radius, 0, 0]}>
          <sphereGeometry args={[size, 24, 24]} />
          <meshStandardMaterial
            color={color}
            emissive={color}
            emissiveIntensity={2.2}
            roughness={0.2}
          />
        </mesh>
      </group>
    </group>
  );
}

/* ---------- Floating geometric satellites ---------- */
interface Satellite {
  position: [number, number, number];
  color: string;
  geometry: "octa" | "tetra" | "box" | "dodeca";
  scale: number;
  wire: boolean;
}

const SATELLITES: Satellite[] = [
  { position: [-2.7, 1.5, -0.4], color: "#34d399", geometry: "octa", scale: 0.26, wire: false },
  { position: [2.5, -1.5, 0.4], color: "#22d3ee", geometry: "tetra", scale: 0.3, wire: true },
  { position: [2.6, 1.9, -0.8], color: "#a78bfa", geometry: "box", scale: 0.24, wire: false },
  { position: [-2.4, -1.9, 0.5], color: "#f472b6", geometry: "dodeca", scale: 0.22, wire: true },
  { position: [0.4, 2.7, -1.2], color: "#fbbf24", geometry: "octa", scale: 0.16, wire: false },
];

function SatelliteGeometry({ type }: { type: Satellite["geometry"] }) {
  switch (type) {
    case "tetra":
      return <tetrahedronGeometry args={[1, 0]} />;
    case "box":
      return <boxGeometry args={[1.2, 1.2, 1.2]} />;
    case "dodeca":
      return <dodecahedronGeometry args={[1, 0]} />;
    default:
      return <octahedronGeometry args={[1, 0]} />;
  }
}

function Satellites() {
  return (
    <>
      {SATELLITES.map((s, i) => (
        <Float
          key={i}
          speed={2 + i * 0.35}
          rotationIntensity={1.6}
          floatIntensity={1.8}
        >
          <mesh position={s.position} scale={s.scale}>
            <SatelliteGeometry type={s.geometry} />
            <meshStandardMaterial
              color={s.color}
              emissive={s.color}
              emissiveIntensity={s.wire ? 1.2 : 0.5}
              roughness={0.3}
              metalness={0.6}
              wireframe={s.wire}
              flatShading
            />
          </mesh>
        </Float>
      ))}
    </>
  );
}

function Lights() {
  return (
    <>
      <ambientLight intensity={0.5} />
      <directionalLight position={[5, 6, 4]} intensity={1.4} color="#ffffff" />
      <pointLight position={[-5, -3, 3]} intensity={32} color="#22d3ee" distance={22} />
      <pointLight position={[5, 4, -2]} intensity={26} color="#10b981" distance={22} />
      <pointLight position={[0, -5, 3]} intensity={16} color="#a78bfa" distance={18} />
    </>
  );
}

/* ---------- Public component ---------- */
export default function HeroScene() {
  const pointer = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      pointer.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      pointer.current.y = -(e.clientY / window.innerHeight) * 2 + 1;
    };
    window.addEventListener("mousemove", onMove, { passive: true });
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  return (
    <div className="absolute inset-0" aria-hidden="true">
      <Canvas
        dpr={[1, 1.75]}
        camera={{ position: [0, 0, 7.4], fov: 45 }}
        gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
      >
        <Suspense fallback={null}>
          <Lights />
          <Rig pointer={pointer}>
            <CoreBlob />
            <WireShell />
            <Orbit radius={2.15} tilt={[1.25, 0.25, 0]} speed={0.7} color="#22d3ee" />
            <Orbit radius={2.6} tilt={[1.05, -0.55, 0.35]} speed={-0.45} color="#a78bfa" />
            <Orbit radius={2.95} tilt={[1.75, 0.65, -0.25]} speed={0.35} color="#34d399" size={0.07} />
            <Satellites />
          </Rig>
          <Sparkles count={110} scale={[9, 7, 5]} size={2.2} speed={0.35} opacity={0.55} color="#a7f3d0" />
          <Stars radius={50} depth={30} count={1200} factor={3} saturation={0} fade speed={0.5} />
        </Suspense>
      </Canvas>
    </div>
  );
}
