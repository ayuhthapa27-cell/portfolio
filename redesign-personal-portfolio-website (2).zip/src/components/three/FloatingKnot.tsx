import { Suspense, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Float, Sparkles } from "@react-three/drei";
import type { Group } from "three";
import { cn } from "../../utils/cn";

function Knot() {
  const group = useRef<Group>(null);

  useFrame((_, delta) => {
    const g = group.current;
    if (!g) return;
    g.rotation.x += delta * 0.25;
    g.rotation.y += delta * 0.35;
  });

  return (
    <group ref={group}>
      <mesh>
        <torusKnotGeometry args={[1, 0.32, 200, 28]} />
        <meshStandardMaterial
          color="#10b981"
          emissive="#065f46"
          emissiveIntensity={0.5}
          metalness={0.85}
          roughness={0.2}
        />
      </mesh>
      <mesh scale={1.06}>
        <torusKnotGeometry args={[1, 0.32, 80, 10]} />
        <meshBasicMaterial color="#67e8f9" wireframe transparent opacity={0.14} />
      </mesh>
    </group>
  );
}

export default function FloatingKnot({ className }: { className?: string }) {
  return (
    <div className={cn("relative", className)} aria-hidden="true">
      <Canvas
        dpr={[1, 1.5]}
        camera={{ position: [0, 0, 5.2], fov: 45 }}
        gl={{ antialias: true, alpha: true }}
      >
        <Suspense fallback={null}>
          <ambientLight intensity={0.5} />
          <directionalLight position={[4, 5, 4]} intensity={1.2} />
          <pointLight position={[3, 3, 3]} intensity={24} color="#34d399" distance={14} />
          <pointLight position={[-3, -2, 2]} intensity={20} color="#22d3ee" distance={14} />
          <Float speed={2} rotationIntensity={1} floatIntensity={1.4}>
            <Knot />
          </Float>
          <Sparkles count={45} scale={5} size={1.8} speed={0.3} opacity={0.6} color="#a7f3d0" />
        </Suspense>
      </Canvas>
    </div>
  );
}
