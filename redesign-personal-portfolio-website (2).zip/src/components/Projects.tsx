import { ExternalLink, Check, X, ArrowUpRight } from "lucide-react";
import SectionHeading from "./ui/SectionHeading";
import Reveal from "./ui/Reveal";
import TiltCard from "./ui/TiltCard";
import { GithubIcon } from "./ui/BrandIcons";
import { projects, type Project } from "../data/portfolio";
import { cn } from "../utils/cn";

/* ---------- Mini CSS mock-ups (rendered in 3D layers) ---------- */

function PortfolioMock() {
  return (
    <div className="mock-window w-56 sm:w-64">
      <div className="mock-bar">
        <span />
        <span />
        <span />
        <div className="ml-2 h-1.5 flex-1 rounded bg-white/10" />
      </div>
      <div className="space-y-3 p-3">
        <div className="flex justify-end gap-1.5">
          {[0, 1, 2, 3].map((i) => (
            <span key={i} className={cn("h-1 w-5 rounded", i === 0 ? "bg-emerald-400" : "bg-white/20")} />
          ))}
        </div>
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 shrink-0 rounded-full bg-linear-to-br from-emerald-400 to-cyan-400" />
          <div className="flex-1 space-y-1.5">
            <div className="h-2 w-2/3 rounded bg-white/80" />
            <div className="h-1.5 w-1/2 rounded bg-emerald-400/80" />
            <div className="h-1.5 w-5/6 rounded bg-white/15" />
          </div>
        </div>
        <div className="flex gap-1.5">
          <div className="h-4 w-12 rounded bg-blue-500/70" />
          <div className="h-4 w-12 rounded bg-pink-500/70" />
        </div>
        <div className="grid grid-cols-3 gap-1.5">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-9 rounded-md border border-white/10 border-l-2 border-l-emerald-400 bg-white/5" />
          ))}
        </div>
      </div>
    </div>
  );
}

function CalculatorMock() {
  const keys = ["C", "÷", "×", "⌫", "7", "8", "9", "−", "4", "5", "6", "+", "1", "2", "3", "=", "0", "."];
  const isOp = (k: string) => ["C", "÷", "×", "⌫", "−", "+"].includes(k);
  return (
    <div className="mock-window w-40 sm:w-44">
      <div className="px-3 pt-3 pb-1 text-right">
        <div className="text-[10px] text-slate-400">12 × 8</div>
        <div className="font-display text-2xl font-bold text-white">96</div>
      </div>
      <div className="grid grid-cols-4 gap-1 p-2">
        {keys.map((k) => (
          <div
            key={k}
            className={cn(
              "grid h-6 place-items-center rounded text-[10px] font-semibold",
              k === "="
                ? "row-span-2 bg-linear-to-b from-emerald-400 to-cyan-400 text-ink-950"
                : isOp(k)
                  ? "bg-emerald-400/15 text-emerald-300"
                  : "bg-white/5 text-slate-200",
              k === "0" && "col-span-2"
            )}
          >
            {k}
          </div>
        ))}
      </div>
    </div>
  );
}

function QuizMock() {
  const options = [
    { label: "A. A database", state: "idle" },
    { label: "B. Markup language", state: "correct" },
    { label: "C. A browser", state: "wrong" },
    { label: "D. A framework", state: "idle" },
  ] as const;
  return (
    <div className="mock-window w-56 sm:w-64">
      <div className="space-y-2.5 p-3">
        <div className="flex items-center justify-between text-[10px] text-slate-400">
          <span>Question 3 / 10</span>
          <span className="rounded-full bg-emerald-400/15 px-2 py-0.5 font-semibold text-emerald-300">
            Score: 2
          </span>
        </div>
        <div className="h-1 overflow-hidden rounded bg-white/10">
          <div className="h-full w-[30%] rounded bg-linear-to-r from-emerald-400 to-cyan-400" />
        </div>
        <p className="text-[11px] font-semibold text-white">What is HTML?</p>
        <div className="space-y-1.5">
          {options.map((o) => (
            <div
              key={o.label}
              className={cn(
                "flex items-center justify-between rounded-md border px-2 py-1 text-[10px]",
                o.state === "correct" && "border-emerald-400/60 bg-emerald-400/15 text-emerald-200",
                o.state === "wrong" && "border-rose-400/50 bg-rose-400/10 text-rose-200",
                o.state === "idle" && "border-white/10 bg-white/5 text-slate-300"
              )}
            >
              {o.label}
              {o.state === "correct" && <Check size={10} strokeWidth={3} />}
              {o.state === "wrong" && <X size={10} strokeWidth={3} />}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Mock({ type }: { type: Project["mock"] }) {
  if (type === "calculator") return <CalculatorMock />;
  if (type === "quiz") return <QuizMock />;
  return <PortfolioMock />;
}

/* ---------- Project card ---------- */

function ProjectCard({ project, index }: { project: Project; index: number }) {
  return (
    <Reveal delay={index * 120} className="h-full">
      <TiltCard max={8} scale={1.02} className="group h-full rounded-3xl">
        <div className="card-border glass absolute inset-0 rounded-3xl transition-colors duration-500 group-hover:bg-white/[0.07]" />

        <div className="relative flex h-full flex-col">
          {/* Preview */}
          <div className="relative h-64 overflow-visible rounded-t-3xl">
            <div
              className={cn(
                "absolute inset-0 rounded-t-3xl bg-linear-to-br",
                project.accent
              )}
            />
            <div className="dot-pattern absolute inset-0 rounded-t-3xl opacity-50 [mask-image:radial-gradient(ellipse_at_center,black,transparent_75%)]" />

            <span className="depth-1 font-display absolute top-5 left-6 text-5xl font-bold text-white/10 transition-colors duration-500 group-hover:text-emerald-400/30">
              {project.number}
            </span>

            <div className="depth-2 absolute inset-0 grid place-items-center">
              <div className="rotate-[-4deg] transition-transform duration-500 group-hover:rotate-0 group-hover:scale-105">
                <Mock type={project.mock} />
              </div>
            </div>
          </div>

          {/* Body */}
          <div className="depth-1 flex flex-1 flex-col p-6 pt-2">
            <h3 className="font-display text-xl font-semibold text-white transition-colors group-hover:text-emerald-300">
              {project.title}
            </h3>
            <p className="mt-2 flex-1 text-sm leading-relaxed text-slate-400">
              {project.description}
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {project.tags.map((t) => (
                <span key={t} className="chip">
                  {t}
                </span>
              ))}
            </div>
            <div className="mt-5 flex items-center gap-3 border-t border-white/10 pt-4">
              <a
                href={project.demo}
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-emerald-300 transition-colors hover:text-emerald-200"
              >
                <ExternalLink size={15} />
                Live demo
              </a>
              <a
                href={project.source}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-400 transition-colors hover:text-white"
              >
                <GithubIcon size={15} />
                Source
              </a>
              <span className="ml-auto grid h-9 w-9 place-items-center rounded-full border border-white/10 text-slate-400 transition-all duration-300 group-hover:border-emerald-400/50 group-hover:bg-emerald-400/10 group-hover:text-emerald-300">
                <ArrowUpRight size={16} />
              </span>
            </div>
          </div>
        </div>
      </TiltCard>
    </Reveal>
  );
}

export default function Projects() {
  return (
    <section id="projects" className="section">
      <div className="container-x">
        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <SectionHeading
            eyebrow="Projects"
            title={
              <>
                Things I've <span className="gradient-text">built</span>
              </>
            }
            description="A few projects I created while learning. Each one taught me something new about structure, logic and design."
          />
          <Reveal delay={200}>
            <a
              href={projects[0].source}
              target="_blank"
              rel="noreferrer"
              className="btn-ghost"
            >
              <GithubIcon size={16} />
              See more on GitHub
            </a>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {projects.map((p, i) => (
            <ProjectCard key={p.id} project={p} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
