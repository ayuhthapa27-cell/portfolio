import { useEffect } from "react";

export default function Background() {
  useEffect(() => {
    const root = document.documentElement;
    const onMove = (e: MouseEvent) => {
      root.style.setProperty("--spot-x", `${e.clientX}px`);
      root.style.setProperty("--spot-y", `${e.clientY}px`);
    };
    window.addEventListener("mousemove", onMove, { passive: true });
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  return (
    <div
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
      aria-hidden="true"
    >
      <div className="grid-bg absolute inset-0" />
      <div className="animate-orb absolute -top-40 -left-40 h-[480px] w-[480px] rounded-full bg-emerald-500/20 blur-3xl" />
      <div className="animate-orb absolute top-1/3 -right-48 h-[460px] w-[460px] rounded-full bg-cyan-500/15 blur-3xl [animation-delay:-6s]" />
      <div className="animate-orb absolute -bottom-48 left-1/4 h-[520px] w-[520px] rounded-full bg-violet-500/15 blur-3xl [animation-delay:-11s]" />
      <div className="spotlight absolute inset-0" />
    </div>
  );
}
