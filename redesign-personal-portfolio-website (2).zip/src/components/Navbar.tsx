import { useEffect, useState } from "react";
import { Menu, X, Send, FileCode } from "lucide-react";
import { cn } from "../utils/cn";
import { navLinks } from "../data/portfolio";
import { useActiveSection } from "../hooks/useActiveSection";

const ids = navLinks.map((l) => l.id);

interface NavbarProps {
  onOpenCssModal?: () => void;
}

export default function Navbar({ onOpenCssModal }: NavbarProps) {
  const active = useActiveSection(ids);
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 30);
      const max =
        document.documentElement.scrollHeight - window.innerHeight;
      setProgress(max > 0 ? Math.min(1, window.scrollY / max) : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close the mobile menu when resizing to desktop
  useEffect(() => {
    const onResize = () => {
      if (window.innerWidth >= 768) setOpen(false);
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      {/* Scroll progress */}
      <div
        className="h-[3px] origin-left bg-linear-to-r from-emerald-400 via-cyan-400 to-violet-400 transition-transform duration-150"
        style={{ transform: `scaleX(${progress})` }}
      />

      <nav className="container-x mt-3">
        <div
          className={cn(
            "flex items-center justify-between rounded-2xl px-4 py-3 transition-all duration-500",
            scrolled || open
              ? "glass shadow-2xl shadow-black/40"
              : "border border-transparent bg-transparent"
          )}
        >
          <a
            href="#home"
            className="font-display group flex items-center gap-2 text-xl font-bold tracking-tight text-white"
          >
            <span className="relative grid h-9 w-9 place-items-center overflow-hidden rounded-xl bg-linear-to-br from-emerald-400 to-cyan-400 text-sm font-black text-ink-950 shadow-lg shadow-emerald-500/30">
              AT
              <span className="animate-shimmer absolute inset-y-0 w-1/3 -skew-x-12 bg-white/40" />
            </span>
            <span>
              Ayush<span className="gradient-text">.</span>
            </span>
          </a>

          <ul className="hidden items-center gap-1 md:flex">
            {navLinks.map((link) => {
              const isActive = active === link.id;
              return (
                <li key={link.id}>
                  <a
                    href={`#${link.id}`}
                    className={cn(
                      "relative rounded-xl px-4 py-2 text-sm font-medium transition-colors duration-300",
                      isActive
                        ? "text-emerald-300"
                        : "text-slate-400 hover:text-white"
                    )}
                  >
                    {isActive && (
                      <span className="absolute inset-0 -z-10 rounded-xl border border-emerald-400/25 bg-emerald-400/10" />
                    )}
                    {link.label}
                  </a>
                </li>
              );
            })}
          </ul>

          <div className="hidden items-center gap-2 md:flex">
            {onOpenCssModal && (
              <button
                type="button"
                onClick={onOpenCssModal}
                className="inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3.5 py-2 text-xs font-semibold text-slate-300 transition-all hover:border-emerald-400/40 hover:text-emerald-300 hover:bg-white/10"
              >
                <FileCode size={14} className="text-emerald-400" />
                style.css
              </button>
            )}
            <a href="#contact" className="btn-primary px-5! py-2.5!">
              <Send size={15} />
              Hire Me
            </a>
          </div>

          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white transition-colors hover:border-emerald-400/40 md:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Mobile menu */}
        <div
          className={cn(
            "overflow-hidden transition-all duration-400 ease-out md:hidden",
            open ? "mt-2 max-h-[460px] opacity-100" : "max-h-0 opacity-0"
          )}
        >
          <div className="glass flex flex-col gap-1 rounded-2xl p-2">
            {navLinks.map((link, i) => (
              <a
                key={link.id}
                href={`#${link.id}`}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center justify-between rounded-xl px-4 py-3 text-sm font-medium transition-colors",
                  active === link.id
                    ? "bg-emerald-400/10 text-emerald-300"
                    : "text-slate-300 hover:bg-white/5 hover:text-white"
                )}
                style={{ transitionDelay: `${i * 30}ms` }}
              >
                {link.label}
                <span className="text-xs text-slate-500">0{i + 1}</span>
              </a>
            ))}
            {onOpenCssModal && (
              <button
                type="button"
                onClick={() => {
                  setOpen(false);
                  onOpenCssModal();
                }}
                className="mt-1 flex items-center justify-between rounded-xl border border-emerald-400/25 bg-emerald-400/10 px-4 py-2.5 text-xs font-semibold text-emerald-300"
              >
                <span className="flex items-center gap-2">
                  <FileCode size={14} />
                  Get style.css & HTML
                </span>
                <span className="text-[10px] uppercase tracking-wider text-emerald-400">3D CSS</span>
              </button>
            )}
            <a
              href="#contact"
              onClick={() => setOpen(false)}
              className="btn-primary mt-1"
            >
              <Send size={15} />
              Hire Me
            </a>
          </div>
        </div>
      </nav>
    </header>
  );
}
