import { ArrowRight, Mail, MapPin, Sparkles, CodeXml, ChevronDown } from "lucide-react";
import HeroScene from "./three/HeroScene";
import Reveal from "./ui/Reveal";
import { FacebookIcon, GithubIcon, InstagramIcon } from "./ui/BrandIcons";
import { profile } from "../data/portfolio";
import { useTypewriter } from "../hooks/useTypewriter";

const socials = [
  {
    label: "Facebook",
    href: profile.socials.facebook,
    icon: FacebookIcon,
    hover: "hover:border-blue-400/60 hover:text-blue-300 hover:shadow-blue-500/30",
  },
  {
    label: "Instagram",
    href: profile.socials.instagram,
    icon: InstagramIcon,
    hover: "hover:border-pink-400/60 hover:text-pink-300 hover:shadow-pink-500/30",
  },
  {
    label: "GitHub",
    href: profile.socials.github,
    icon: GithubIcon,
    hover: "hover:border-slate-200/60 hover:text-white hover:shadow-white/20",
  },
  {
    label: "Email",
    href: `mailto:${profile.email}`,
    icon: Mail,
    hover: "hover:border-emerald-400/60 hover:text-emerald-300 hover:shadow-emerald-500/30",
  },
];

export default function Hero() {
  const role = useTypewriter(profile.roles);

  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center overflow-hidden pt-28 pb-20"
    >
      <div className="container-x grid items-center gap-10 lg:grid-cols-2 lg:gap-6">
        {/* ---------- Copy ---------- */}
        <div className="relative z-10 text-center lg:text-left">
          <Reveal>
            <span className="chip border-emerald-400/30 bg-emerald-400/10 text-emerald-300">
              <span className="relative flex h-2 w-2">
                <span className="animate-pulse-ring absolute inline-flex h-full w-full rounded-full bg-emerald-400" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
              </span>
              Open to learning opportunities
            </span>
          </Reveal>

          <Reveal delay={100}>
            <h1 className="font-display mt-6 text-4xl leading-[1.05] font-bold tracking-tight text-white sm:text-5xl md:text-6xl xl:text-7xl">
              Hi, I'm{" "}
              <span className="gradient-text-animated">{profile.name}</span>
            </h1>
          </Reveal>

          <Reveal delay={200}>
            <p className="font-display mt-5 flex min-h-[2.5rem] items-center justify-center gap-2 text-xl font-semibold text-slate-200 sm:text-2xl lg:justify-start">
              <Sparkles size={20} className="shrink-0 text-cyan-300" />
              <span>
                {role}
                <span className="animate-blink ml-0.5 inline-block h-[1.1em] w-[2px] translate-y-[3px] bg-emerald-400" />
              </span>
            </p>
          </Reveal>

          <Reveal delay={300}>
            <p className="mx-auto mt-5 max-w-xl text-base leading-relaxed text-slate-400 md:text-lg lg:mx-0">
              {profile.tagline}
            </p>
          </Reveal>

          <Reveal delay={400}>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-3 lg:justify-start">
              <a href="#projects" className="btn-primary group">
                View Projects
                <ArrowRight
                  size={16}
                  className="transition-transform duration-300 group-hover:translate-x-1"
                />
              </a>
              <a href="#contact" className="btn-ghost">
                <Mail size={16} />
                Contact Me
              </a>
            </div>
          </Reveal>

          <Reveal delay={500}>
            <div className="mt-8 flex items-center justify-center gap-3 lg:justify-start">
              {socials.map(({ label, href, icon: Icon, hover }) => (
                <a
                  key={label}
                  href={href}
                  target={href.startsWith("http") ? "_blank" : undefined}
                  rel="noreferrer"
                  aria-label={label}
                  title={label}
                  className={`grid h-11 w-11 place-items-center rounded-xl border border-white/10 bg-white/5 text-slate-400 shadow-lg shadow-transparent transition-all duration-300 hover:-translate-y-1 ${hover}`}
                >
                  <Icon size={18} />
                </a>
              ))}
              <span className="ml-1 hidden h-px w-14 bg-linear-to-r from-white/20 to-transparent sm:block" />
              <span className="hidden items-center gap-1.5 text-xs font-medium text-slate-500 sm:flex">
                <MapPin size={13} className="text-emerald-400" />
                {profile.location}
              </span>
            </div>
          </Reveal>
        </div>

        {/* ---------- 3D scene ---------- */}
        <Reveal direction="zoom" duration={1000} className="relative">
          <div className="relative mx-auto h-[360px] w-full max-w-[620px] sm:h-[460px] lg:h-[600px]">
            {/* glow behind */}
            <div className="absolute top-1/2 left-1/2 h-[55%] w-[55%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-emerald-500/25 blur-3xl" />
            <HeroScene />

            {/* Floating chips */}
            <div className="animate-float glass pointer-events-none absolute top-8 left-0 hidden items-center gap-3 rounded-2xl px-4 py-3 shadow-xl shadow-black/30 sm:flex">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-emerald-400/15 text-emerald-300">
                <CodeXml size={18} />
              </span>
              <div>
                <p className="text-xs text-slate-400">Currently building with</p>
                <p className="text-sm font-semibold text-white">HTML • CSS • JS</p>
              </div>
            </div>

            <div className="animate-float-slow glass pointer-events-none absolute right-0 bottom-16 hidden items-center gap-3 rounded-2xl px-4 py-3 shadow-xl shadow-black/30 sm:flex [animation-delay:-3s]">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-cyan-400/15 text-cyan-300">
                <Sparkles size={18} />
              </span>
              <div>
                <p className="text-xs text-slate-400">Goal</p>
                <p className="text-sm font-semibold text-white">Full-Stack Developer</p>
              </div>
            </div>

            <div className="animate-float glass pointer-events-none absolute bottom-4 left-6 hidden rounded-2xl px-4 py-2 shadow-xl shadow-black/30 sm:block [animation-delay:-1.5s]">
              <p className="font-display text-lg font-bold text-white">
                3<span className="text-emerald-400">+</span>
                <span className="ml-2 text-xs font-medium text-slate-400">projects shipped</span>
              </p>
            </div>
          </div>
        </Reveal>
      </div>

      {/* Scroll cue */}
      <a
        href="#about"
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-xs tracking-widest text-slate-500 uppercase transition-colors hover:text-emerald-300 md:flex"
        aria-label="Scroll to about section"
      >
        <span className="flex h-9 w-6 items-start justify-center rounded-full border border-white/20 p-1">
          <span className="animate-scroll-dot h-1.5 w-1.5 rounded-full bg-emerald-400" />
        </span>
        <ChevronDown size={14} />
      </a>
    </section>
  );
}
