import { useState, type FormEvent } from "react";
import { Mail, Phone, MapPin, Send, CircleCheck, Copy, Check } from "lucide-react";
import SectionHeading from "./ui/SectionHeading";
import Reveal from "./ui/Reveal";
import TiltCard from "./ui/TiltCard";
import FloatingKnot from "./three/FloatingKnot";
import { FacebookIcon, GithubIcon, InstagramIcon } from "./ui/BrandIcons";
import { profile } from "../data/portfolio";

const details = [
  {
    label: "Email",
    value: profile.email,
    href: `mailto:${profile.email}`,
    icon: Mail,
    color: "text-emerald-300 bg-emerald-400/15",
    copy: true,
  },
  {
    label: "Phone",
    value: profile.phone,
    href: profile.phoneHref,
    icon: Phone,
    color: "text-cyan-300 bg-cyan-400/15",
    copy: true,
  },
  {
    label: "Location",
    value: profile.location,
    href: "https://www.google.com/maps/place/Nepal",
    icon: MapPin,
    color: "text-violet-300 bg-violet-400/15",
    copy: false,
  },
];

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Portfolio contact from ${form.name || "a visitor"}`);
    const body = encodeURIComponent(
      `${form.message}\n\n— ${form.name}${form.email ? ` (${form.email})` : ""}`
    );
    window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`;
    setSent(true);
    window.setTimeout(() => setSent(false), 5000);
  };

  const copyToClipboard = async (value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(value);
      window.setTimeout(() => setCopied(null), 2000);
    } catch {
      /* clipboard not available */
    }
  };

  return (
    <section id="contact" className="section">
      <div className="container-x">
        <SectionHeading
          eyebrow="Contact"
          align="center"
          title={
            <>
              Let's <span className="gradient-text">connect</span>
            </>
          }
          description="If you would like to get in touch, feel free to reach out through any of the details below!"
        />

        <div className="mt-14 grid gap-8 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
          {/* ---------- Left: 3D + details ---------- */}
          <div className="flex flex-col gap-4">
            <Reveal direction="left">
              <div className="card-border glass relative overflow-hidden rounded-3xl">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_60%,rgba(16,185,129,0.18),transparent_60%)]" />
                <FloatingKnot className="h-56 sm:h-64" />
                <div className="pointer-events-none absolute bottom-4 left-5 flex items-center gap-2 text-xs font-semibold text-slate-300">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-pulse-ring absolute inline-flex h-full w-full rounded-full bg-emerald-400" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
                  </span>
                  Usually replies within a day
                </div>
              </div>
            </Reveal>

            {details.map((d, i) => {
              const Icon = d.icon;
              return (
                <Reveal key={d.label} direction="left" delay={100 + i * 90}>
                  <TiltCard max={6} scale={1.01} className="rounded-2xl">
                    <div className="card-border glass absolute inset-0 rounded-2xl" />
                    <div className="relative flex items-center gap-4 p-4">
                      <span className={`grid h-12 w-12 shrink-0 place-items-center rounded-xl ${d.color}`}>
                        <Icon size={20} />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs tracking-widest text-slate-500 uppercase">{d.label}</p>
                        <a
                          href={d.href}
                          target={d.href.startsWith("http") ? "_blank" : undefined}
                          rel="noreferrer"
                          className="block truncate text-sm font-semibold text-white transition-colors hover:text-emerald-300"
                        >
                          {d.value}
                        </a>
                      </div>
                      {d.copy && (
                        <button
                          type="button"
                          onClick={() => copyToClipboard(d.value)}
                          className="grid h-9 w-9 place-items-center rounded-lg border border-white/10 text-slate-400 transition-colors hover:border-emerald-400/40 hover:text-emerald-300"
                          aria-label={`Copy ${d.label}`}
                        >
                          {copied === d.value ? <Check size={15} /> : <Copy size={15} />}
                        </button>
                      )}
                    </div>
                  </TiltCard>
                </Reveal>
              );
            })}

            <Reveal direction="left" delay={400}>
              <div className="flex items-center gap-3 pt-2">
                <span className="text-xs tracking-widest text-slate-500 uppercase">Follow</span>
                <span className="h-px flex-1 bg-white/10" />
                <a
                  href={profile.socials.facebook}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="Facebook"
                  className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-slate-400 transition-all hover:-translate-y-0.5 hover:border-blue-400/60 hover:text-blue-300"
                >
                  <FacebookIcon />
                </a>
                <a
                  href={profile.socials.instagram}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="Instagram"
                  className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-slate-400 transition-all hover:-translate-y-0.5 hover:border-pink-400/60 hover:text-pink-300"
                >
                  <InstagramIcon />
                </a>
                <a
                  href={profile.socials.github}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="GitHub"
                  className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-slate-400 transition-all hover:-translate-y-0.5 hover:border-white/60 hover:text-white"
                >
                  <GithubIcon />
                </a>
              </div>
            </Reveal>
          </div>

          {/* ---------- Right: form ---------- */}
          <Reveal direction="right" delay={150}>
            <TiltCard max={4} scale={1.005} className="h-full rounded-3xl">
              <div className="card-border glass absolute inset-0 rounded-3xl" />
              <form onSubmit={handleSubmit} className="relative flex h-full flex-col p-6 sm:p-8">
                <h3 className="font-display text-2xl font-semibold text-white">
                  Send me a message
                </h3>
                <p className="mt-1 text-sm text-slate-400">
                  Fill in the form and it will open your email app with everything pre-filled.
                </p>

                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <label className="block">
                    <span className="mb-1.5 block text-xs font-semibold tracking-widest text-slate-400 uppercase">
                      Name
                    </span>
                    <input
                      required
                      type="text"
                      className="input"
                      placeholder="Your name"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                    />
                  </label>
                  <label className="block">
                    <span className="mb-1.5 block text-xs font-semibold tracking-widest text-slate-400 uppercase">
                      Email
                    </span>
                    <input
                      required
                      type="email"
                      className="input"
                      placeholder="you@example.com"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                    />
                  </label>
                </div>

                <label className="mt-4 block flex-1">
                  <span className="mb-1.5 block text-xs font-semibold tracking-widest text-slate-400 uppercase">
                    Message
                  </span>
                  <textarea
                    required
                    rows={6}
                    className="input min-h-[160px] resize-y"
                    placeholder="Hi Ayush, I'd love to talk about..."
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                  />
                </label>

                <div className="mt-6 flex flex-wrap items-center gap-4">
                  <button type="submit" className="btn-primary group">
                    Send message
                    <Send size={16} className="transition-transform group-hover:translate-x-1 group-hover:-translate-y-0.5" />
                  </button>
                  {sent && (
                    <span className="inline-flex items-center gap-2 text-sm font-medium text-emerald-300">
                      <CircleCheck size={16} />
                      Opening your email app…
                    </span>
                  )}
                </div>
              </form>
            </TiltCard>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
