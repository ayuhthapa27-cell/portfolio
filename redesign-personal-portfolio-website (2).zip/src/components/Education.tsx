import { BookOpen, CodeXml, GraduationCap, Clock, Award } from "lucide-react";
import SectionHeading from "./ui/SectionHeading";
import Reveal from "./ui/Reveal";
import TiltCard from "./ui/TiltCard";
import { education, type EducationItem } from "../data/portfolio";
import { cn } from "../utils/cn";

const icons: Record<EducationItem["icon"], typeof GraduationCap> = {
  cap: GraduationCap,
  book: BookOpen,
  code: CodeXml,
};

export default function Education() {
  return (
    <section id="education" className="section">
      <div className="container-x grid gap-14 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)] lg:gap-20">
        {/* Sticky heading */}
        <div className="lg:sticky lg:top-32 lg:self-start">
          <SectionHeading
            eyebrow="Education & Training"
            title={
              <>
                My learning <span className="gradient-text">journey</span>
              </>
            }
            description="I believe in learning by doing — every course, class and tutorial turns into something I can build."
          />

          <Reveal delay={200}>
            <div className="mt-8 flex items-center gap-4 rounded-2xl border border-white/10 bg-white/5 p-5">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-linear-to-br from-emerald-400/20 to-cyan-400/20 text-emerald-300">
                <Award size={22} />
              </span>
              <div>
                <p className="text-sm font-semibold text-white">Step by step, every day</p>
                <p className="text-sm text-slate-400">
                  Consistency over intensity — small wins compound.
                </p>
              </div>
            </div>
          </Reveal>
        </div>

        {/* Timeline */}
        <div className="relative">
          <div className="absolute top-2 bottom-2 left-6 w-px bg-linear-to-b from-emerald-400/0 via-emerald-400/50 to-emerald-400/0" />

          <div className="space-y-8">
            {education.map((item, i) => {
              const Icon = icons[item.icon];
              return (
                <Reveal key={item.title} delay={i * 120} direction="right">
                  <div className="relative pl-20">
                    {/* node */}
                    <div className="absolute top-6 left-6 -translate-x-1/2">
                      <span className="relative grid h-11 w-11 place-items-center rounded-full border border-emerald-400/40 bg-ink-900 text-emerald-300 shadow-[0_0_30px_rgba(52,211,153,0.35)]">
                        <Icon size={18} />
                        {item.statusTone === "live" && (
                          <span className="animate-pulse-ring absolute inset-0 rounded-full border border-emerald-400/60" />
                        )}
                      </span>
                    </div>

                    <TiltCard max={6} scale={1.01} className="rounded-2xl">
                      <div className="card-border glass absolute inset-0 rounded-2xl" />
                      <div className="relative p-6">
                        <div className="depth-1 flex flex-wrap items-center gap-2">
                          <span
                            className={cn(
                              "chip",
                              item.statusTone === "live"
                                ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-300"
                                : "border-violet-400/30 bg-violet-400/10 text-violet-300"
                            )}
                          >
                            <span
                              className={cn(
                                "h-1.5 w-1.5 rounded-full",
                                item.statusTone === "live" ? "bg-emerald-400" : "bg-violet-400"
                              )}
                            />
                            {item.status}
                          </span>
                          <span className="chip">
                            <Clock size={12} /> {item.period}
                          </span>
                        </div>
                        <h3 className="font-display depth-1 mt-4 text-xl font-semibold text-white">
                          {item.title}
                        </h3>
                        <p className="depth-1 mt-1 text-sm font-medium text-cyan-300">
                          {item.subtitle}
                        </p>
                        <p className="depth-1 mt-3 text-sm leading-relaxed text-slate-400">
                          {item.description}
                        </p>
                      </div>
                    </TiltCard>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
