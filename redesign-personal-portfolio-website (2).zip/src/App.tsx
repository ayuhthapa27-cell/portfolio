import { useState } from "react";
import { FileCode } from "lucide-react";
import Background from "./components/Background";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Skills from "./components/Skills";
import Projects from "./components/Projects";
import Education from "./components/Education";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import CssModal from "./components/CssModal";

export default function App() {
  const [cssModalOpen, setCssModalOpen] = useState(false);

  return (
    <div className="relative min-h-screen">
      <Background />
      <Navbar onOpenCssModal={() => setCssModalOpen(true)} />
      <main>
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Education />
        <Contact />
      </main>
      <Footer onOpenCssModal={() => setCssModalOpen(true)} />

      {/* Floating style.css pill button */}
      <button
        type="button"
        onClick={() => setCssModalOpen(true)}
        className="fixed right-5 bottom-5 z-40 flex items-center gap-2 rounded-full border border-emerald-400/40 bg-ink-900/90 px-4 py-2.5 text-xs font-semibold text-emerald-300 shadow-xl shadow-black/60 backdrop-blur transition-all duration-300 hover:scale-105 hover:border-emerald-400 hover:bg-ink-800 hover:shadow-emerald-500/20 active:scale-95"
        title="View & Download style.css"
      >
        <FileCode size={15} className="text-emerald-400" />
        <span>style.css & HTML</span>
      </button>

      {/* Interactive Modal */}
      <CssModal open={cssModalOpen} onClose={() => setCssModalOpen(false)} />
    </div>
  );
}
